package models;

public class Client {

    private String fullName;
    private String email;
    private double dueAmount;

    public Client(String fullName, String email, double dueAmount) {
        this.fullName = fullName;
        this.email = email;
        this.dueAmount = dueAmount;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getDueAmount() {
        return dueAmount;
    }

    public void setDueAmount(double dueAmount) {
        this.dueAmount = dueAmount;
    }

    @Override
    public String toString() {
        return "Client{" +
                "fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", dueAmount=" + dueAmount +
                '}';
    }
}

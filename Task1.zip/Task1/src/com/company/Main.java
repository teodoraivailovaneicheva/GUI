package com.company;

import frames.TableFrame;

public class Main {

    public static void main(String[] args) {

        TableFrame frame = new TableFrame();
        frame.setVisible(true);
    }
}
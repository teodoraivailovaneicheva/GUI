package panels;
import frames.TableFrame;
import models.Client;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ClientsPanel extends BasePanel implements TableModelListener {
    public DefaultTableModel clientsTableModel;
    public JTable clientsTable;
    public JTextField fullNameField;
    public JTextField emailField;
    public JTextField dueAmountField;
    public JLabel fullNameLabel;
    public JLabel emailLabel;
    public JLabel dueAmountLabel;
    public JButton deleteButton;
    public JButton addButton;
    public JButton printButton;
    public JButton exportDataButton;


    public ClientsPanel(TableFrame frame) {
        super(frame);

        String cols[] = {"Full Name", "Email address", "Due Amount"};
        clientsTableModel = new DefaultTableModel();
        clientsTableModel.setColumnIdentifiers(cols);
        clientsTable = new JTable(clientsTableModel);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        clientsTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        clientsTable.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);

        JScrollPane clientsTablePane = new JScrollPane(clientsTable);
        clientsTablePane.setBounds(0, 0, frame.getWidth(), 200);
        add(clientsTablePane);
        frame.dataProvider.fetchClients(clientsTableModel);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(0, clientsTablePane.getHeight() + 150, 150, 40);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteClient();
            }
        });
        add(deleteButton);

        JButton addButton = new JButton("Add");
        addButton.setBounds(0, clientsTablePane.getHeight() + 80, 150, 40);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addClient();
            }
        });
        add(addButton);

        JButton printButton = new JButton("Print");
        printButton.setBounds(0, clientsTablePane.getHeight() + 200, 150, 40);
        printButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printTable();
            }
        });
        add(printButton);

        JButton exportDataButton = new JButton("Export data");
        exportDataButton.setBounds(0,clientsTablePane.getHeight() + 250,150,40);
        exportDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                exportData();
            }
        });
        add(exportDataButton);

        initializeTextFields();

        clientsTable.getModel().addTableModelListener(this);
        clientsTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer()
        {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
            {
                final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(row % 2 == 0 ? Color.LIGHT_GRAY : Color.WHITE);
                return c;
            }
        });
    }

    public void exportData(){

    }

    public void deleteClient() {
        if (clientsTable.getSelectedRow() < 0) {
            showError("You have no selected client!");
            return;
        }
        boolean isYes = showQuestionPopup("Are you sure you want to delete this client?");
        if (isYes) {
            Client selectedClient = frame.dataProvider.clients.get(clientsTable.getSelectedRow());
            if (selectedClient.getDueAmount() > 0) {
                showError("You cannot delete client obligations!");
                return;
            }
            frame.dataProvider.clients.remove(clientsTable.getSelectedRow());
            frame.dataProvider.fetchClients(clientsTableModel);
        }
    }

    public void addClient() {
        String dueAmountFieldText = String.valueOf(dueAmountField.getText());
        if (fullNameField.getText().isEmpty() || fullNameField.getText().length() < 3) {
            showError("Please enter a valid name!");
            return;
        } else if (emailField.getText().isEmpty() || emailField.getText().length() < 10 || !emailField.getText().contains("@")) {
            showError("Please enter a valid email!");
            return;
        } else if (dueAmountFieldText.length() < 1) {
            showError("This field can not be empty!");
        }

        Client newClient = new Client(fullNameField.getText(), emailField.getText(), Double.valueOf(dueAmountFieldText));
        frame.dataProvider.clients.add(newClient);
        frame.dataProvider.fetchClients(clientsTableModel);
    }

    public void initializeTextFields() {
        fullNameLabel = new JLabel("Enter name");
        fullNameLabel.setBounds(0, 200, 100, 30);
        add(fullNameLabel);

        fullNameField = new JTextField();
        fullNameField.setBounds(0, 230, 150, 40);
        add(fullNameField);

        emailLabel = new JLabel("Enter email");
        emailLabel.setBounds(fullNameLabel.getX() + 170, fullNameLabel.getY(), 100, 30);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(fullNameField.getX() + 170, fullNameField.getY(), 150, 40);
        add(emailField);

        dueAmountLabel = new JLabel("Enter due");
        dueAmountLabel.setBounds(emailField.getX() + 170, emailLabel.getY(), 100, 30);
        add(dueAmountLabel);

        dueAmountField = new JTextField();
        dueAmountField.setBounds(emailField.getX() + 170, emailField.getY(), 150, 40);
        add(dueAmountField);
    }

    public void printTable(){

        try {
            if (! clientsTable.print()) {
                System.err.println("User cancelled printing");
            }
        } catch (java.awt.print.PrinterException e) {
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }

    @Override
    public void tableChanged(TableModelEvent e) {
        int row = e.getFirstRow();
        int column = e.getColumn();
        TableModel tableModel = (TableModel) e.getSource();
        String columnName = tableModel.getColumnName(column);
        Object data = tableModel.getValueAt(row, column);
    }
}


package frames;

import panels.*;

public class TableRouter {

    public TableFrame frame;

    public TableRouter(TableFrame frame){
        this.frame = frame;
    }

    public void showContactsPanel(){
        ClientsPanel panel = new ClientsPanel(frame);
        this.frame.setContentPane(panel);
        this.frame.validate();
    }
}

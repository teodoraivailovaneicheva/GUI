package frames;

import javax.swing.*;

public class TableFrame extends JFrame{

    public TableRouter router;
    public TableDataProvider dataProvider;

    public TableFrame(){
        super("Clients Book");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000,700);
        dataProvider = new TableDataProvider();
        router = new TableRouter(this);
        router.showContactsPanel();
    }
}


package frames;

import models.Client;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class TableDataProvider{

    public ArrayList<Client> clients;
    public ArrayList<Client> searchedClients;
    public boolean isSearchingClients;

    public TableDataProvider(){
        clients = new ArrayList<>();

        Client client1 = new Client("Ivan Ivanov","IvanIvanov@abv.bg",500.44);
        Client client2 = new Client("Petyr Petrov","PetyrPetrov@abv.bg",50.00);
        Client client3 = new Client("Anna Georgieva","AnnaGeorgieva@abv.bg",2123.99);
        Client client4 = new Client("Vasil Dimov","VasilDimmov@abv.bg",0);
        Client client5 = new Client("Elena Savova","ElenaSavova@abv.bg",15.63);

        clients.add(client1);
        clients.add(client2);
        clients.add(client3);
        clients.add(client4);
        clients.add(client5);

    }

    public void fetchClients(DefaultTableModel model) {
        model.setRowCount(0);
        ArrayList<Client> activeClientList;
        if(isSearchingClients) {
            activeClientList = new ArrayList<>(searchedClients);
        } else {
            activeClientList = new ArrayList<>(clients);
        }
        for(Client client : activeClientList) {
            String row[] = new String[3];
            row[0] = client.getFullName();
            row[1] = client.getEmail();
            row[2] = String.valueOf(client.getDueAmount());
            model.addRow(row);
        }
    }
}

